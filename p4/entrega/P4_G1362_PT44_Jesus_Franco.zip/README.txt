Práctica 4 ARQO 2019-2020

Jesús Daniel Franco López, Grupo 1362, PT44

En esta carpeta se entrega lo pedido en Moodle:
	- Memoria con las respuestas a todas las preguntas del enunciado
	- Resultados de los datos obtenidos para los ejercicios necesarios
	- Código fuente desarrollado para el ejercicio 3, es decir, paralelización de cada uno de los bucles de la multiplicación de matrices

Asimismo, se entregan en las subcarpetas correspondientes a los ejercicios 2 y 3 los scripts utilizados para la resolución de la tarea planteada.
Estos son ejercicio2.bash, ejercicio3.bash y ejercicio3_graficatiempos.sh.